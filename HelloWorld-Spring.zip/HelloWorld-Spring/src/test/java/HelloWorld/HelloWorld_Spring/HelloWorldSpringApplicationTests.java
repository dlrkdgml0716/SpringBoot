package HelloWorld.HelloWorld_Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWorldSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
